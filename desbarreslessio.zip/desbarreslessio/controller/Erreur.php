<?php
class Erreur extends Controller
{
    function perdu(){
        $this->render('404');
    }
}
?>

