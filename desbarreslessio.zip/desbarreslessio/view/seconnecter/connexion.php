 <!-- Connexion -->
  <section class="page-section" id="commande">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 text-center">

<?php 

    echo "Je suis connect&eacute;(e) et je dispose des informations suivantes :";
    var_dump($_SESSION['auteur']);

?>
</div>
</div>
</div>
</section>