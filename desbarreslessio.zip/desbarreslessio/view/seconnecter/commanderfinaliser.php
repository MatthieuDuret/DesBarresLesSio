  <section class="page-section" id="commanderfinaliser">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 text-center">
			<h1>Merci pour votre achat !</h1>
			<br> <br>
			<h5> Paiement effectué ! </h5>

<a href="<?= WEBROOT.'blague' ?>">
	<button type="button" style="margin:20px" >
		Continuer
	</button>
</a>
</div>
</div>
</div>
</section>