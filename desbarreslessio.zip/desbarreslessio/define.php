<?php 
define('WEBROOT',str_replace('index.php','',$_SERVER['SCRIPT_NAME']));
define('ROOT',str_replace('index.php','',$_SERVER['SCRIPT_FILENAME']));
define('IMAGE','http://localhost/desbarreslessio3/asset/');
define('SCRIPT','http://localhost/desbarreslessio3/asset/js/');



//$GLOBAL['pdo']=$pdo->exec('SET NAMES utf8');



?>