<?php
class Blagues extends Model
{
    var $table="blagues";  
}
?>
