<?php
class Lcommande extends Model
{
    var $table="lcommande";
}

?>
