<?php
class Commande extends Model
{
    var $table="commande";
    
   
}

?>

